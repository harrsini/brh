from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializers import LoginSerializer, get_tokens_for_user


class StudentLoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        
        if serializer.is_valid():
            user = serializer.validated_data["user"]

            if user.role != "student":
                return Response(
                    {"error": "Not a student account"},
                    status=status.HTTP_403_FORBIDDEN
                )

            tokens = get_tokens_for_user(user)

            return Response({
                "message": "Student login successful",
                "tokens": tokens
            })

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class FacultyLoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)

        if serializer.is_valid():
            user = serializer.validated_data["user"]

            if user.role != "faculty":
                return Response(
                    {"error": "Not a faculty account"},
                    status=status.HTTP_403_FORBIDDEN
                )

            tokens = get_tokens_for_user(user)

            return Response({
                "message": "Faculty login successful",
                "tokens": tokens
            })

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
from rest_framework.permissions import IsAuthenticated


class ProfileView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        return Response({
            "username": user.username,
            "email": user.email,
            "role": user.role
        })
