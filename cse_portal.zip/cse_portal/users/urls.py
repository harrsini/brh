from django.urls import path
from .views import StudentLoginView, FacultyLoginView, ProfileView

urlpatterns = [
    path('student/login/', StudentLoginView.as_view()),
    path('faculty/login/', FacultyLoginView.as_view()),
    path('profile/', ProfileView.as_view()),
]
