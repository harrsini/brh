from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Program, Semester
from .serializers import ProgramSerializer, SemesterSerializer


class ProgramListView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        programs = Program.objects.all()
        serializer = ProgramSerializer(programs, many=True)
        return Response(serializer.data)


class SemesterSubjectsView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, semester_id):
        semester = Semester.objects.get(id=semester_id)
        serializer = SemesterSerializer(semester)
        return Response(serializer.data)
