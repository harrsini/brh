from django.urls import path
from .views import ProgramListView, SemesterSubjectsView

urlpatterns = [
    path('programs/', ProgramListView.as_view()),
    path('semesters/<int:semester_id>/', SemesterSubjectsView.as_view()),
]
