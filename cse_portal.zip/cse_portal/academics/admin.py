from django.contrib import admin
from .models import Program, Semester, Subject


admin.site.register(Program)
admin.site.register(Semester)
admin.site.register(Subject)
