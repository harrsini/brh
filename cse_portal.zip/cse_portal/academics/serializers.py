from rest_framework import serializers
from .models import Program, Semester, Subject


class SubjectSerializer(serializers.ModelSerializer):
    faculty_name = serializers.CharField(source="faculty.username", read_only=True)

    class Meta:
        model = Subject
        fields = "__all__"


class SemesterSerializer(serializers.ModelSerializer):
    subjects = SubjectSerializer(many=True, read_only=True)

    class Meta:
        model = Semester
        fields = "__all__"


class ProgramSerializer(serializers.ModelSerializer):
    semesters = SemesterSerializer(many=True, read_only=True)

    class Meta:
        model = Program
        fields = "__all__"
