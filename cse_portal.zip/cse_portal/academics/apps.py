from django.apps import AppConfig


class AcademicsConfig(AppConfig):
    name = 'academics'
