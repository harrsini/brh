from rest_framework import serializers


class StudentDashboardSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    email = serializers.EmailField()
    program = serializers.CharField()
    semester = serializers.CharField()
    subjects = serializers.ListField()

class FacultyDashboardSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    name = serializers.CharField()
    email = serializers.EmailField()
    subjects = serializers.ListField()

class AdminDashboardSerializer(serializers.Serializer):
    total_students = serializers.IntegerField()
    total_faculty = serializers.IntegerField()
    total_programs = serializers.IntegerField()
    total_subjects = serializers.IntegerField()
