from django.apps import AppConfig


class LmsConfig(AppConfig):
    name = 'lms'
