from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated

from users.models import CustomUser
from academics.models import Program, Semester, Subject

from .serializers import (
    StudentDashboardSerializer,
    FacultyDashboardSerializer,
    AdminDashboardSerializer
)


class DashboardView(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        # ======================
        # STUDENT DASHBOARD
        # ======================
        if user.role == "student":
            semester = user.semester

            if not semester:
                return Response({"error": "Student not assigned to any semester"})

            subjects = semester.subjects.all()

            data = {
                "id": user.id,
                "name": user.username,
                "email": user.email,
                "program": semester.program.name,
                "semester": f"Semester {semester.semester_number}",
                "subjects": [sub.subject_name for sub in subjects]
            }

            serializer = StudentDashboardSerializer(data)
            return Response(serializer.data)

        # ======================
        # FACULTY DASHBOARD
        # ======================
        elif user.role == "faculty":

            subjects = user.subject_set.all()
            subject_data = []

            for sub in subjects:
                semester = sub.semester
                student_count = semester.students.count()

                subject_data.append({
                    "subject_code": sub.subject_code,
                    "subject_name": sub.subject_name,
                    "program": semester.program.name,
                    "semester": f"Semester {semester.semester_number}",
                    "student_count": student_count
                })

            data = {
                "id": user.id,
                "name": user.username,
                "email": user.email,
                "subjects": subject_data
            }

            serializer = FacultyDashboardSerializer(data)
            return Response(serializer.data)

        # ======================
        # ADMIN DASHBOARD
        # ======================
        elif user.role == "admin":
            data = {
                "total_students": CustomUser.objects.filter(role="student").count(),
                "total_faculty": CustomUser.objects.filter(role="faculty").count(),
                "total_programs": Program.objects.count(),
                "total_subjects": Subject.objects.count(),
            }

            serializer = AdminDashboardSerializer(data)
            return Response(serializer.data)

        return Response({"error": "Invalid role"}, status=400)
